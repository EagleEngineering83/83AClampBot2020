/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Fri 31 January 2020                                       */
/*    Description:  Competition: Mecanum-Clamp Bot                            */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// leftFrontDrive       motor         19              
// leftRearDrive        motor         20              
// rightRearDrive       motor         2               
// rightFrontDrive      motor         1               
// leftLift             motor         10              
// rightLift            motor         11              
// clamp                motor         21              
// turnSense            inertial      9               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "math.h"
#include "vex.h"
#include "robot-config.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here
int e_forward = 1;
int e_backward = -1;
int e_straight = 0;
int e_lateral = 0;
int e_turn = 0;
int count = 0;

//Turn Left and Right using Time
void turnLeftRight(double time,double velocity,bool direction)
{ //left is true/right is false
    if (direction == true)
    {
        leftFrontDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
        leftRearDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
        rightFrontDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
        rightRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
    }
   else
   {
        leftFrontDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
        leftRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct);
        rightFrontDrive.rotateFor(time,timeUnits::sec,-velocity,velocityUnits::pct);
        rightRearDrive.rotateFor(time,timeUnits::sec,velocity,velocityUnits::pct); 
   }
} 

//Stop the Whole Base
void stopBase()
{
    
    rightFrontDrive.stop();
    leftFrontDrive.stop();
    leftRearDrive.stop();
    rightRearDrive.stop();  
    
}

//Moving with Encoders of SmartMotors:
void moveWithEncoder(double travelTargetCM, double velocity, int direction)
{
    double circ = 4 * 2.54 * M_PI;
    double dTR = (360 * travelTargetCM) / circ; //All calculations are complete. Start the rest of the program.
   
    //Set the velocity of the left and right motors to whatever power we want. This command will not make the motor spin.
    leftFrontDrive.setVelocity(velocity * direction, vex::velocityUnits::pct); 
    leftRearDrive.setVelocity(velocity * direction, vex::velocityUnits::pct);
    rightFrontDrive.setVelocity(velocity * direction, vex::velocityUnits::pct);
    rightRearDrive.setVelocity(velocity * direction, vex::velocityUnits::pct);
    
    
    //Rotate the Left and Right Motor for degreesToRotate. 
   leftFrontDrive.rotateFor(dTR*direction, vex::rotationUnits::deg, false); //This command must be non blocking.
   leftRearDrive.rotateFor(dTR*direction, vex::rotationUnits::deg, false); //This command is blocking so the program will wait here until the right motor is done.
   rightFrontDrive.rotateFor(dTR*direction, vex::rotationUnits::deg, false);
   rightRearDrive.rotateFor(dTR*direction, vex::rotationUnits::deg);
    //The motors will brake once they reach their destination.
}
void straight(int speed)
{
  leftFrontDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  rightFrontDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  leftRearDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  rightRearDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
}
void rotate(int speed)
{
  leftFrontDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  rightFrontDrive.spin(vex::directionType::fwd, -speed , vex::velocityUnits::pct);
  leftRearDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  rightRearDrive.spin(vex::directionType::fwd, -speed , vex::velocityUnits::pct);
}
void lateral(int speed)
{
  leftFrontDrive.spin(vex::directionType::fwd, -speed , vex::velocityUnits::pct);
  rightFrontDrive.spin(vex::directionType::fwd, -speed , vex::velocityUnits::pct);
  leftRearDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
  rightRearDrive.spin(vex::directionType::fwd, speed , vex::velocityUnits::pct);
}
void stop_base(){
  leftFrontDrive.stop();
  rightFrontDrive.stop();
  leftRearDrive.stop();
  rightRearDrive.stop();
}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // Callibrate the inertial sensor.
  turnSense.startCalibration();
  while(turnSense.isCalibrating()){
    wait(10,msec);

  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  task::sleep(1000);
  straight(50);
  task::sleep(1000);
  rotate(50);
  task::sleep(1000);
  stop_base();

  lateral(50);
  task::sleep(1000);
  stop_base();

 
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  //int rightSpeed;
  //int leftSpeed;
  int deadzone = 10;
  deadzone = abs(deadzone);
  while(true)
  {
    if(Controller1.Axis3.value() < deadzone && Controller1.Axis3.value() > -deadzone)//straight
    {
      e_straight = 0;

    }
    else
    {
      e_straight = Controller1.Axis3.value();
    }

    if(Controller1.Axis1.value() > deadzone && Controller1.Axis1.value() < -deadzone)//turn
    {
      e_turn = 0;
    }
    else
    {
      e_turn = Controller1.Axis1.value();
    }

    if(Controller1.Axis4.value() > deadzone && Controller1.Axis4.value() < -deadzone)//turn
    {
      e_lateral = 0;
    }
    else
    {
      e_lateral = Controller1.Axis4.value();
    }

    int leftFrontSpeed = 0;
    int leftRearSpeed = 0;
    int rightFrontSpeed = 0;
    int rightRearSpeed = 0;
    int liftSpeed = 0;
    int clampSpeed = 0;

    leftFrontSpeed = e_straight + e_turn - e_lateral;
    rightFrontSpeed =  e_straight - e_turn - e_lateral;
    leftRearSpeed = e_straight + e_turn + e_lateral;
    rightRearSpeed = e_straight - e_turn + e_lateral;

    leftFrontDrive.spin(vex::directionType::fwd, leftFrontSpeed, vex::velocityUnits::pct);
    rightFrontDrive.spin(vex::directionType::fwd, rightFrontSpeed, vex::velocityUnits::pct);
    leftRearDrive.spin(vex::directionType::fwd, leftRearSpeed, vex::velocityUnits::pct);
    rightRearDrive.spin(vex::directionType::fwd, rightRearSpeed, vex::velocityUnits::pct);

    //lift control
    if(Controller1.ButtonL2.pressing()) //lift goes down
    {
      leftLift.spin(vex::directionType::fwd, -liftSpeed , vex::velocityUnits::pct);
      rightLift.spin(vex::directionType::fwd, -liftSpeed , vex::velocityUnits::pct);
       Brain.Screen.clearScreen();
       Brain.Screen.setCursor(1,0);
       Brain.Screen.print("lift down");
      
    }
    else if(Controller1.ButtonL1.pressing()) //lift goes up
    {
      leftLift.spin(vex::directionType::fwd, liftSpeed , vex::velocityUnits::pct);
      rightLift.spin(vex::directionType::fwd, liftSpeed , vex::velocityUnits::pct);
      Brain.Screen.clearScreen();
      Brain.Screen.setCursor(1,0);
      Brain.Screen.print(leftLift.power());
      Brain.Screen.print(rightLift.power());
    }
    else //stop lift
    {
      leftLift.stop();
      rightLift.stop();
    }
    
    //clamp control
    if(Controller1.ButtonR1.pressing()) //clamp closes
    {
      clamp.spin(vex::directionType::fwd, -clampSpeed , vex::velocityUnits::pct);
    }
    else if(Controller1.ButtonR2.pressing()) //clamp opens
    {
      clamp.spin(vex::directionType::fwd, clampSpeed , vex::velocityUnits::pct);
    }
    else //stop clamp
    {
      clamp.spin(vex::directionType::fwd, 0 , vex::velocityUnits::pct);
    }
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

// Main will set up the competition functions and callbacks.

int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}