using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor leftFrontDrive;
extern motor leftRearDrive;
extern motor rightRearDrive;
extern motor rightFrontDrive;
extern motor leftLift;
extern motor rightLift;
extern motor clamp;
extern inertial turnSense;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Text.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );